// #include "Bot.hpp"

// // public **********************************************************************

// //  constructors & destructor --------------------------------------------------

// //  default constructor
// Bot::Bot() {
//   std::cout << "Bot Created!!" << std::endl;
//   // Initialize variables.
//   socket_fd_ = -1;
//   nick_ = kDefaultNick;
//   user_name_ = kDefaultUserName;
//   host_name_ = kDefaultHostName;
//   server_name_ = kDefaultServerName;
//   real_name_ = kDefaultRealName;
//   server_.ip_ = kDefaultServerIP;
//   server_.port_ = kDefaultServerPort;
//   server_.password_ = kDefaultServerPassword;
// }

// //  destructor
// Bot::~Bot() {
//   // TODO
// }

// //  functions ------------------------------------------------------------------

// // Start the bot.
// void Bot::Start() {
//   std::cout << "Starting bot..." << std::endl;
//   // Ask user for server IP, port and password.
//   if (!kUseDefaultServerInfo) {
//     AskUserForServerInfo();
//   }

//   // Ask user for nick and user.
//   if (!kUseDefaultBotInfo) {
//     AskUserForBotInfo();
//   }

//   // Connect to server.
//   try {
//     ConnectToServer();
//   } catch (MyExceptions &e) {
//     std::cout << e.What() << std::endl;
//     exit(1);
//   }

//   // set stdin to non-blocking
//   Socket::SetNonBlocking(STDIN_FILENO);

//   // Ask user's choice.
//   while (true) {
//     // Handle Ping.
//     HandlePing();
//     // Clear the screen.
//     std::system("clear");
//     // Display Menu
//     std::cout << "BOT MENU" << std::endl;
//     std::cout << "0. Quit" << std::endl;
//     std::cout << "1. Join a channel" << std::endl;
//     std::cout << "2. Send a message to a channel" << std::endl;
//     std::cout << "3. Send Ping to channel" << std::endl;
//     std::cout << "Enter your choice: ";
//     std::string choice;
//     std::cin >> choice;
//     if (choice == "0") {
//       break;
//     } else if (choice == "1") {
//       AskUserToJoinChannel();
//     } else if (choice == "2") {
//       std::cout << "Enter the channel name: ";
//       std::string channel;
//       std::cin >> channel;
//       std::cout << "Enter the message: ";
//       std::string message;
//       std::cin >> message;
//       SendMessageToChannel(channel, message);
//     } else if (choice == "3") {
//       // Send ping to server.
//       std::string message = BuildMessage(kPING);
//       Socket::Send(socket_fd_, message);
//     } else {
//       std::cout << "Invalid choice." << std::endl;
//     }
//   }
//   Stop();
// }

// void Bot::Stop() {
//   std::cout << "Stopping bot..." << std::endl;
//   Socket::Close(socket_fd_);
// }

// // TODO

// // private *********************************************************************

// //  functions ------------------------------------------------------------------

// // Ask the user for the server IP, port and password.
// void Bot::AskUserForServerInfo() {
//   // Ask user for server IP. If the user enters an invalid IP, ask again.
//   // If the user enters "quit", exit the program.
//   while (true) {
//     std::cout << "Enter the server IP: ";
//     std::string server_ip;
//     std::cin >> server_ip;
//     if (server_ip == "quit") {
//       exit(0);
//     }
//     if (MyUtils::IsValidIP(server_ip)) {
//       server_.ip_ = server_ip;
//       break;
//     }
//     std::cout << "Invalid IP address." << std::endl;
//   }

//   // Ask user for server port. If the user enters an invalid port, ask again.
//   // If the user enters "quit", exit the program.
//   while (true) {
//     std::cout << "Enter the server port: ";
//     std::string server_port;
//     std::cin >> server_port;
//     if (server_port == "quit") {
//       exit(0);
//     }
//     int port = MyUtils::IsValidPort(server_port.c_str());
//     if (port != -1) {
//       server_.port_ = port;
//       break;
//     }
//     std::cout << "Invalid port number format." << std::endl;
//   }

//   // Ask user for server password. If the user enters an invalid password, ask
//   // again. If the user enters "quit", exit the program.
//   while (true) {
//     std::cout << "Enter the server password: ";
//     std::string server_password;
//     std::cin >> server_password;
//     if (server_password == "quit") {
//       exit(0);
//     }
//     if (MyUtils::IsValidPassword(server_password.c_str())) {
//       server_.password_ = server_password;
//       break;
//     }
//     std::cout << "Invalid password format." << std::endl;
//   }
// }

// // Ask the user for the nick and user.
// void Bot::AskUserForBotInfo() {
//   // Ask user for bot nick. If the user enters an invalid nick, ask again.
//   // If the user enters "quit", exit the program.
//   while (true) {
//     std::cout << "Enter the nick for bot: ";
//     std::string bot_nick;
//     std::cin >> bot_nick;
//     if (bot_nick == "quit") {
//       exit(0);
//     }
//     if (MyUtils::IsValidNick(bot_nick)) {
//       nick_ = bot_nick;
//       break;
//     }
//     std::cout << "Invalid nick." << std::endl;
//   }

//   // Ask user for bot real name. If the user enters an invalid real name, ask
//   // again. If the user enters "quit", exit the program.
//   while (true) {
//     std::cout << "Enter your real name: ";
//     std::string bot_real_name;
//     std::cin >> bot_real_name;
//     if (bot_real_name == "quit") {
//       exit(0);
//     }
//     if (MyUtils::IsValidRealName(bot_real_name)) {
//       real_name_ = bot_real_name;
//       break;
//     }
//     std::cout << "Invalid real name." << std::endl;
//   }
// }

// // Connect to the server.
// void Bot::ConnectToServer() {
//   // Create a socket
//   socket_fd_ = Socket::CreateSocket();
//   // Connect to the server
//   Socket::Connect(socket_fd_, server_.port_, server_.ip_.c_str());
//   // Send the password to the server
//   Socket::Send(socket_fd_, BuildMessage(kPASS, server_.password_));
//   // Send the nick to the server
//   Socket::Send(socket_fd_, BuildMessage(kNICK, nick_));
//   // Send the user to the server
//   Socket::Send(socket_fd_, BuildMessage(kUSER, user_name_ + " 0 *", real_name_));
//   // Receive the welcome message from the server
//   std::string welcome_message = Socket::Receive(socket_fd_);

//   std::cout << welcome_message << std::endl;  // FOR TEST

//   // Check if the welcome message is valid
//   // if (!MyUtils::IsValidWelcomeMessage(welcome_message)) {
//   //   throw MyExceptions("Invalid welcome message. Failed to Join the server.");
//   // } else {
//   //   std::cout << "Welcome message: " << welcome_message << std::endl;
//   //   std::cout << "Successfully joined the server." << std::endl;
//   // }
// }

// std::string Bot::GetCommandString(Command command) const {
//   if (command == kQUIT) return "QUIT";
//   if (command == kPASS) return "PASS";
//   if (command == kNICK) return "NICK";
//   if (command == kUSER) return "USER";
//   if (command == kJOIN) return "JOIN";
//   if (command == kPRIVMSG) return "PRIVMSG";
//   if (command == kPONG) return "PONG";
//   if (command == kPING) return "kPING";
//   return "";
// }

// // Build a message to send to the server.
// std::string Bot::BuildMessage(const std::string &prefix, Command command,
//                               const std::string &message,
//                               const std::string &trailing) const {
//   std::stringstream ss;
//   if (!prefix.empty()) {
//     ss << ":" << prefix << " ";
//   }
//   ss << GetCommandString(command) << " ";
//   if (!message.empty()) {
//     ss << message << " ";
//   }
//   if (!trailing.empty()) {
//     ss << ":" << trailing;
//   }
//   ss << "\r\n";
//   return ss.str();
// }

// std::string Bot::BuildMessage(Command command,
//                               const std::string &message) const {
//   return BuildMessage("", command, message, "");
// }

// std::string Bot::BuildMessage(Command command, const std::string &message,
//                               const std::string &trailing) const {
//   return BuildMessage("", command, message, trailing);
// }

// std::string Bot::BuildMessage(Command command) const {
//   return BuildMessage("", command, "", "");
// }

// // Ask the user for the channel to join.
// void Bot::AskUserToJoinChannel() {
//   while (true) {
//     std::cout << "Enter the channel to join: ";
//     std::string channel;
//     std::cin >> channel;
//     if (channel == "quit") {
//       exit(0);
//     }
//     if (MyUtils::IsValidChannel(channel)) {
//       if (JoinChannel(channel)) {
//         channels_.push_back(channel);
//         break;
//       }
//     }
//     std::cout << "Invalid channel." << std::endl;
//   }
// }

// // Join a channel.
// bool Bot::JoinChannel(const std::string &channel) {
//   try {
//     std::string channel_name = "#" + channel;
//     // Send the join message to the server
//     Socket::Send(socket_fd_, BuildMessage(kJOIN, channel_name));
//     // Receive the join message from the server
//     std::string join_message = Socket::Receive(socket_fd_);
//     // Check if the join message is valid
//     if (MyUtils::IsJoinFailedMessage(join_message)) {
//       std::cout << "Failed to join the channel." << std::endl;
//       return false;
//     }
//     return true;
//   } catch (MyExceptions &e) {
//     std::cout << e.What() << std::endl;
//     return false;
//   }
// }

// void Bot::SendMessageToChannel(const std::string &channel,
//                                const std::string &message) {
//   // Check if the channel is valid
//   for (std::vector<std::string>::iterator it = channels_.begin();
//        it != channels_.end(); ++it) {
//     if (*it == channel) {
//       break;
//     }
//     if (it == channels_.end() - 1) {
//       std::cout << "Invalid channel." << std::endl;
//       return;
//     }
//   }
//   // Check if the message is too long
//   if (message.length() > kMaxMessageLength) {
//     std::cout << "Message is too long." << std::endl;
//     return;
//   }
//   try {
//     // Send the message to the server
//     Socket::Send(socket_fd_, BuildMessage(kPRIVMSG, channel, message));
//   } catch (MyExceptions &e) {
//     std::cout << e.What() << std::endl;
//   }
// }