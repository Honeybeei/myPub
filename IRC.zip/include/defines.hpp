#ifndef DEFINES_HPP_
#define DEFINES_HPP_

const static int kChannelMaxClientCnt = 4;

#endif